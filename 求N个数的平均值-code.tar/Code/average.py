#!/usr/bin/env python3
n = int(input("输入你要输入几个数字："))
Avg = 0
for i in range(1,n+1):
    a = input("输入你的第{}个数字：".format(i))
    a += a
Avg = a/n
print("{}个数的平均值为：{}".format(n,Avg))
