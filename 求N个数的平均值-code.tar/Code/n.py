#!/usr/bin/env python3
N = int(input("请输入你要输入几个数："))
sum = 0
count = 0
while count < N:
    nubmer = float(input("请输入第{}个数:".format(count+1)))
    sum += nubmer
    count += 1
Avg = sum/N
print("{}个数的平均值为：{}".format(N,Avg))
