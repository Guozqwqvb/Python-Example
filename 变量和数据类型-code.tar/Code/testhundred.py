#!/usr/bin/env python3
number = int(input("请输入你想输入的数："))
if number > 100:
    print("你输入的数字是：{}，小于我们提供的要求".format(number))
elif number < 100:
    print("你输入的数字是：{}，大于我们提供的要求".format(number))
else:
    print("你输入的数字是：{}，等于我们提供的要求".format(number))
