#!/usr/bin/env python3
amount = float(input("输入存款金额："))
inrate = float(input("输入年利率："))
period = float(input("输入存款期限："))

value = 0
year = 1

while year <= period:
    value = amount + (amount * inrate)
    print("第{}年，账户金额：{:.3f}".format(year,value)) # {}用str.format()初始化的，{:.3f}表示保留3位小数
    amount = value
    year += 1
